/*****************************************************************//**
 * @file main_sampler_test.cpp
 *
 * @brief Basic test of nexys4 ddr mmio cores
 *
 * @author p chu
 * @version v1.0: initial release
 *********************************************************************/

// #define _DEBUG
#include "chu_init.h"
#include "gpio_cores.h"
#include "sseg_core.h"
#include "i2c_core.h"
#include <math.h>


/*
 * read temperature from adt7420
 * @param adt7420_p pointer to adt7420 instance
 */
float temperature(I2cCore *adt7420_p, GpoCore *led_p) {
   const uint8_t DEV_ADDR = 0x4b;
   uint8_t wbytes[2], bytes[2];
   uint16_t tmp;
   float tmpC;


   wbytes[0] = 0x0b;
   adt7420_p->write_transaction(DEV_ADDR, wbytes, 1, 1);
   adt7420_p->read_transaction(DEV_ADDR, bytes, 1, 0);


   wbytes[0] = 0x00;
   adt7420_p->write_transaction(DEV_ADDR, wbytes, 1, 1);
   adt7420_p->read_transaction(DEV_ADDR, bytes, 2, 0);

   // conversion
   tmp = (uint16_t) bytes[0];
   tmp = (tmp << 8) + (uint16_t) bytes[1];
   if (tmp & 0x8000) {
      tmp = tmp >> 3;
      tmpC = (float) ((int) tmp - 8192) / 16;
   } else {
      tmp = tmp >> 3;
      tmpC = (float) tmp / 16;
   }

   return tmpC;
}



void Thermometer(float temp, SsegCore* segg, bool mode) {

for (int i = 0; i < 8; i++) {
 segg->write_1ptn(0xff, i);
    }

segg->set_dp(0x00);

if (mode) {
temp = (temp * 1.8) + 32;
segg->write_1ptn(segg->h2s(15), 3);
}
else {
segg->write_1ptn(segg->h2s(12), 3);
}

temp *= 100;

uint8_t num1 = temp / 1000;
uint8_t num2 =(temp - num1 * 1000) / 100;
uint8_t num3 = (temp- num1 * 1000 - num2 * 100) / 10;
uint8_t num4 = (temp - num1 * 1000 - num2 * 100 - num3 * 10);

segg->write_1ptn(segg->h2s(num1), 7);
segg->write_1ptn(segg->h2s(num2), 6);
segg->write_1ptn(segg->h2s(num3), 5);
segg->write_1ptn(segg->h2s(num4), 4);
segg->set_dp(64);
}

GpoCore led(get_slot_addr(BRIDGE_BASE, S2_LED));
GpiCore sw(get_slot_addr(BRIDGE_BASE, S3_SW));
SsegCore sseg(get_slot_addr(BRIDGE_BASE, S8_SSEG));
I2cCore adt7420(get_slot_addr(BRIDGE_BASE, S10_I2C));


int main() {

	float temp;
	int s;

   while (1) {

	   s = sw.read(0);
	   temp = temperature(&adt7420, &led);
	   Thermometer(temp, &sseg, s);



   } //while
} //main

