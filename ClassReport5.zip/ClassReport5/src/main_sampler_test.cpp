/*****************************************************************//**
 * @file main_sampler_test.cpp
 *
 * @brief Basic test of nexys4 ddr mmio cores
 *
 * @author p chu
 * @version v1.0: initial release
 *********************************************************************/

// #define _DEBUG
#include "chu_init.h"
#include "gpio_cores.h"
#include "xadc_core.h"
#include "sseg_core.h"


void ADC_OUT(XadcCore *adc_p, SsegCore* segg, bool mode) {

	double dout;

	for (int i = 0; i < 8; i++) {
			segg->write_1ptn(0xff, i);
	}



	if (mode) {
		dout = adc_p->read_fpga_temp();
		uart.disp("FPGA TEMP (Celsius): ");
		uart.disp(dout, 3);
		uart.disp("\n\r");
		dout *= 100;
		segg->set_dp(64);
		}
	else {
		dout = adc_p->read_fpga_vcc();
		uart.disp("FPGA VCC: ");
		uart.disp(dout, 3);
		uart.disp("\n\r");
		dout *= 1000;
		segg->set_dp(128);
		}



	uint8_t num1 = dout / 1000;
	uint8_t num2 =(dout - num1 * 1000) / 100;
	uint8_t num3 = (dout- num1 * 1000 - num2 * 100) / 10;
	uint8_t num4 = (dout - num1 * 1000 - num2 * 100 - num3 * 10);

	segg->write_1ptn(segg->h2s(num1), 7);
	segg->write_1ptn(segg->h2s(num2), 6);
	segg->write_1ptn(segg->h2s(num3), 5);
	segg->write_1ptn(segg->h2s(num4), 4);


	sleep_ms(200);

	}

GpoCore led(get_slot_addr(BRIDGE_BASE, S2_LED));
GpiCore sw(get_slot_addr(BRIDGE_BASE, S3_SW));
XadcCore adc(get_slot_addr(BRIDGE_BASE, S5_XDAC));
SsegCore sseg(get_slot_addr(BRIDGE_BASE, S8_SSEG));


int main() {

	int s;

	while (1) {

		s = sw.read(0);
		ADC_OUT(&adc, &sseg, s);



	} //while
} //main

